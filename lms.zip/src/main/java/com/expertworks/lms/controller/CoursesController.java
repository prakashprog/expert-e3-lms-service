package com.expertworks.lms.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.expertworks.lms.model.Courses;
import com.expertworks.lms.model.VideoLink;
import com.expertworks.lms.repository.CoursesRepository;

@RestController
@Component
public class CoursesController {

	@Autowired
	private CoursesRepository coursesRepository;

	@GetMapping("/samplecourse/{teamId}")
	public ResponseEntity<Courses> saveCourses(@PathVariable String teamId) {

		Courses courses = new Courses();

		courses.setTeamId("teamId5");
		courses.setCourseId("courseId5");
		courses.setS3folder("s3folder");

		VideoLink videoLink = new VideoLink();
		VideoLink videoLink1 = new VideoLink();

		videoLink.setUrl("https://d3s24np0er9fug.cloudfront.net/sample-mp4-file.mp4");
		videoLink.setType("mp4");

		videoLink1.setUrl("https://d3s24np0er9fug.cloudfront.net/sample-mp4-file.mp4");
		videoLink1.setType("mp4");

		List<VideoLink> videoLinks = new ArrayList();
		videoLinks.add(videoLink);
		videoLinks.add(videoLink1);

		courses.setVideoLinks(videoLinks);

		courses = coursesRepository.save(courses);

		HttpHeaders responseHeaders = new HttpHeaders();
		return new ResponseEntity<>(courses, responseHeaders, HttpStatus.OK);

	}

	@PostMapping("/courses")
	public Courses saveCourses(@RequestBody Courses courses) {
		return coursesRepository.save(courses);
	}

	@GetMapping("/courses/{teamId}/{courseId}")
	public Courses getCourses(@PathVariable("teamId") String teamId,@PathVariable("courseId") String courseId) {
		return coursesRepository.getTeamCourses(teamId,courseId);
	}

	@DeleteMapping("/courses/{id}")
	public String deleteEmployee(@PathVariable("id") String teamId) {
		return coursesRepository.delete(teamId);
	}

	@PutMapping("/courses/{id}")
	public String updateEmployee(@PathVariable("id") String teamId, @RequestBody Courses courses) {
		return coursesRepository.update(teamId, courses);
	}

}
